# Experiment — 10,000-record ingest batching

Status: FAILED — DO NOT REPEAT
Date: day 14

## What we tried

Buffering incoming events into 10,000-record batches before writing to the queue, to
amortise per-write overhead and lift throughput toward the 50k/s target.

## What happened

Resident memory on the ingest nodes grew to 14 GB under a partial-partition stall and
the nodes were OOM-killed. Because the buffer was in-process and unbounded in the
stall path, back-pressure never reached the producers. We lost 41 minutes of
telemetry in staging.

## Conclusion

**Large in-process batching is abandoned.** Any future throughput work must keep the
in-flight buffer bounded and must apply back-pressure at the producer, not at the
broker. Do not reintroduce unbounded in-process batching.
Week 4 standup notes.

- Rename landed; CI green after the path fix.
- Redpanda cluster is handling staging load without the rebalance spikes.
- Someone please claim the umbrella in the meeting room.
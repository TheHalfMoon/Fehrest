# ADR-002 — Queue technology, revised

Status: ACCEPTED
Date: day 21
Supersedes: ADR-001

## Decision

Beacon moves from Kafka to **Redpanda**.

## Context

ADR-001 chose Kafka on the strength of prior team experience. Three weeks of
operating it in staging changed the calculus: the cluster needed two full-time
on-call engineers we do not have, and rebalancing spikes repeatedly pushed p99 past
the 200 ms criterion in the charter.

Redpanda is wire-compatible with the Kafka client protocol, so producer and consumer
code is unchanged. It removes the JVM and the separate coordination tier.

## Consequences

**ADR-001 is superseded and must not be treated as current.** Client libraries stay
on the Kafka protocol; only the broker changes. Operational runbooks written against
Kafka's admin CLI need rewriting.
# Beacon-local exception — synchronous checkpoint writes

Status: APPROVED — SCOPE: BEACON ONLY
Date: day 42

The organisation-wide platform default, recorded in the engineering handbook, is that
**all services write checkpoints asynchronously**.

Beacon is granted an exception: `beacon-gateway` writes its consumer checkpoints
**synchronously**. The no-data-loss-on-broker-restart criterion in the charter cannot
be met with async checkpointing at our restart frequency.

**This exception applies to Beacon and to nothing else.** It is not a change to the
organisation default and must not be cited as precedent for another service.
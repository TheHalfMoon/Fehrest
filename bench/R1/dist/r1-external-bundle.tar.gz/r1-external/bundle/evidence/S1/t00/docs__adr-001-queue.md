# ADR-001 — Queue technology

Status: ACCEPTED
Date: day 0

## Decision

Beacon will use **Kafka** as the ingest queue.

## Context

We need durable ordered partitions and at-least-once delivery. The team has prior
Kafka operational experience from the Halifax project, which shortens ramp-up.

## Consequences

We accept the operational weight of running a ZooKeeper-less Kafka cluster, and we
accept that consumer rebalancing will occasionally add latency spikes.
Week 1 standup notes.

- Kafka cluster provisioned in staging.
- Schema registry stood up.
- Priya is out Thursday and Friday.
- Coffee machine on floor 3 is broken again.
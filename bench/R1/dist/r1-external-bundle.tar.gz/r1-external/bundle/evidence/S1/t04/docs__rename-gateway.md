# Service rename — beacon-ingest becomes beacon-gateway

Date: day 28

The service formerly called `beacon-ingest` is now `beacon-gateway`. The repository
directory moved from `services/beacon-ingest/` to `services/beacon-gateway/`.

This is a rename only. **It is the same service, the same deployment, the same
on-call rotation, and it carries the same history**, including ADR-001, ADR-002, the
PII constraint and the failed batching experiment. Nothing about the rename resets
any prior decision.

Old paths redirect for one release, then are removed.
# Beacon — onboarding summary for new joiners

Last substantive edit: day 12. Lightly touched since.

Beacon ingests device telemetry. The queue is **Kafka**. The service lives in
`services/beacon-ingest/`. Throughput work is focused on batching records together
before the write.

If you are picking this up, start with the Kafka runbook.
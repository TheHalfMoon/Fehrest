From the customer commitments review, day 35:

Aisha stated that the retention window for raw telemetry is **90 days**, because two
enterprise contracts specify 90-day replay. She has the contract language.

Nobody has reconciled this against the storage team's number. **This is unresolved.**
No decision has been recorded either way, and both people are confident.
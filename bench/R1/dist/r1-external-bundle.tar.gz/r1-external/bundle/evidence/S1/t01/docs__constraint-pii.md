# Constraint — PII must be dropped at ingest

Status: BINDING
Introduced: day 7
Raised by: legal review

Device telemetry occasionally carries a `subscriber_id` field. **Beacon must drop
every PII field at the ingest edge, before anything is written to the queue or to
disk.** PII must never be persisted, not even transiently, and not even encrypted.

This is a hard constraint. It is not subject to performance trade-off: if dropping
PII costs latency, we spend the latency.

Fields currently classified PII: `subscriber_id`, `imei`, `handset_serial`.
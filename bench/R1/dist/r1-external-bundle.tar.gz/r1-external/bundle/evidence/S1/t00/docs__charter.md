# Beacon — charter

Beacon ingests device telemetry from field hardware and makes it queryable within
one minute of arrival.

Success criteria agreed at kickoff:

- Sustained ingest of 50,000 events per second.
- End-to-end p99 latency under 200 ms from device ack to queryable.
- No data loss on broker restart.

Owner: platform team. Reviewed weekly.
Week 7 standup notes.

- Dedup shipped. Nobody paged.
- Back-pressure design not started yet.
- Reminder: quarterly compliance training closes Friday.
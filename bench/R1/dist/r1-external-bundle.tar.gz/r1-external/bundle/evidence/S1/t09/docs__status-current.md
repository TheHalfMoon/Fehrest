# Beacon — current state

Date: day 63

Shipped: ingest path, schema validation, PII drop at edge, deduplication.
In progress: nothing.
**Next authorised work item: back-pressure implementation.**

The back-pressure work must apply pressure at the producer. The throughput approach
tried in week 2 is not to be revisited.

Open question still unresolved: retention window.
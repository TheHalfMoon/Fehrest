From the platform sync, day 35:

Marcus stated that the retention window for raw telemetry is **30 days**, and that
this was agreed with the storage team when the cost model was signed off. He is
confident about the number and says the storage budget assumes it.
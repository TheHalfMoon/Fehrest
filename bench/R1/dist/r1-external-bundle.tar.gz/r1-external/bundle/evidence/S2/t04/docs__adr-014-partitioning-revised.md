# ADR-014 — Partition strategy, revised

Status: ACCEPTED
Date: day 40
Supersedes: ADR-011

## Decision

The analysis dataset is partitioned **by protocol version**: `protocol=v2`,
`protocol=v3`.

## Context

ADR-011 partitioned by site. Protocol v3 changed the visit schedule mid-trial, and
every analysis now filters on protocol version first. Site partitioning forced a full
scan for the most common query shape.

Re-delivery isolation, which was ADR-011's motivation, is preserved by the
per-site manifest table rather than by the partition layout.

## Consequences

**ADR-011 is superseded.** Any code or document still asserting site partitioning as
current is stale. The partition key is protocol version.
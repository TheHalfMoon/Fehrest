# ADR-011 — Partition strategy

Status: ACCEPTED
Date: day 20

## Decision

The analysis dataset is partitioned **by site**: `site=lyon`, `site=utrecht`,
`site=cork`.

## Context

Sites deliver on different schedules and re-deliver corrections independently.
Site partitioning lets a single site be reprocessed without touching the others.

## Consequences

Cross-site queries scan every partition. We accept that; the analysis workload is
mostly per-site.
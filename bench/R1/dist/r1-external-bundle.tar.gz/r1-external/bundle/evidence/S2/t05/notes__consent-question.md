Raised at the clinical operations sync, day 50:

Does the Cork site's consent form cover **secondary analysis** of the trial data, or
only the primary endpoint analysis?

- The Lyon and Utrecht forms explicitly cover secondary analysis.
- The Cork form uses different wording and nobody in the meeting could say whether it
  does or not.
- The question has been referred to the sponsor's regulatory counsel.

**No answer has come back. No decision has been recorded. This is open.**

Until counsel responds, nobody should assume either answer.
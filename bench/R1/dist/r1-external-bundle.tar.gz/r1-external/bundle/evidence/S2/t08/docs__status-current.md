# Marisol — current state

Date: day 80

Shipped: nightly ingest, quarantine, manifest reconciliation, protocol-version
partitioning.
In progress: nothing.
**Next authorised work item: the cross-site reconciliation report.**

Constraints in force: EU residency (day 10), change-control citation for schema
changes (day 60).

Open and unresolved: the Cork consent scope question.
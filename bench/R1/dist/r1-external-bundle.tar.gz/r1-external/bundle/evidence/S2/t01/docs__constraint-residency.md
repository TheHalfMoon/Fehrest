# Constraint — subject data must not leave the EU

Status: BINDING — REGULATORY
Introduced: day 10

**No subject-level data may be processed or stored outside the EU region.** This
covers compute, object storage, logs, backups, and any managed service that could
relocate data.

Aggregates that cannot be re-identified may leave the region. Subject-level rows may
not, under any circumstance, including debugging and incident response.

This constraint is regulatory, not architectural preference. It cannot be traded away
for cost or latency, and no engineering decision may weaken it.
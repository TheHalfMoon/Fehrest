# Incident — cross-site join executed in the shared warehouse

Status: ROLLED BACK — APPROACH FORBIDDEN
Date: day 30

## What was tried

To speed up the cross-site reconciliation report, subject-level rows from all three
sites were loaded into the shared analytics warehouse and joined there.

## Why it was wrong

The shared warehouse has a US replica. Loading subject-level rows into it **breached
the day-10 residency constraint**. The breach was caught in review before any
production run, and the staging data was purged under a documented procedure.

## Conclusion

**Subject-level cross-site joins in the shared warehouse are forbidden.** Cross-site
reconciliation must run inside the EU-resident pipeline and emit only aggregates.
Do not reintroduce the warehouse join, in any form, for any performance reason.
# Marisol — charter

Marisol consolidates trial data from three investigator sites — Lyon, Utrecht and
Cork — into a single analysis-ready dataset.

Scope at kickoff:

- Nightly ingest from each site's EDC export.
- Deterministic subject identifiers across sites.
- Analysis dataset regenerated from source on every run; no in-place edits.

Owner: data engineering, with clinical operations as the accountable stakeholder.
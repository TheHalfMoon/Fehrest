Week 10 notes.

- Quarantine path merged.
- Utrecht sent a corrected export for visit 4; reprocessed cleanly.
- Someone rebooted the build agent without telling anyone. Again.
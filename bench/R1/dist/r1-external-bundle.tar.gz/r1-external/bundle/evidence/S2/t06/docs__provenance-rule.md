# Rule — schema changes must cite their change-control ticket

Status: BINDING
Introduced: day 60

Any change to the analysis dataset schema must, in the pull request and in the
migration record, **cite the approving change-control ticket** in the form
`CC-####`.

A schema change without a cited approving ticket is not deployable, regardless of who
wrote it or how urgent it is. Auditors sample migrations and check this.

The rule applies to column additions, removals, renames and type changes. It does not
apply to partition-layout changes, which are covered by the ADR process instead.
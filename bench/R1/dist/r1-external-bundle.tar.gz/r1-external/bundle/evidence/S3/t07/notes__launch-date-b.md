From the release planning meeting, day 63:

Tomas recorded the public launch date as **28 November**, on the basis that the search
reindex and the accessibility audit cannot both complete before then.

The two dates have not been reconciled. **No decision has been taken.** Both were
recorded on the same day by people with reason to know.
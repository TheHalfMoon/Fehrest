# Link rewriter v1 — abandoned

Status: ABANDONED — DO NOT REVIVE
Date: day 27

## What it did

A regex-based rewriter that rewrote legacy wiki links to the new site paths in bulk.

## Why it was abandoned

It matched inside fenced code blocks and inside anchor fragments, silently corrupting
147 pages: code samples had their URLs rewritten, and `#section` anchors were
rewritten to paths that do not exist. The corruption was not caught by the build,
because broken anchors still build.

We reverted the batch. **Regex-based link rewriting is abandoned.** Any future link
work must parse the document rather than pattern-match its text, and must verify
anchors resolve, not merely that the build passes.
Week 8 notes.

- Move landed with redirects in the same PR.
- Search reindex queued.
- The plant in the corner is definitely dead. Removing it.
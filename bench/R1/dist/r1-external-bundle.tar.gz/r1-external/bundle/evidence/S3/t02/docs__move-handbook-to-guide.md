# Directory move — `handbook/` becomes `guide/`

Date: day 18

The `handbook/` directory is renamed to `guide/`. Content is unchanged; only the path
moves. Redirects are in place from the old paths.

This is a path change. **The pages keep their identity, their review sign-off and
their history.** Nothing about the move alters the migration status of any page.
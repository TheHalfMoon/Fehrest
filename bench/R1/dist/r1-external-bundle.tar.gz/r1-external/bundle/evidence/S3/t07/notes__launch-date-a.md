From the programme review, day 63:

Dana recorded the public launch date for the documentation site as **14 November**,
and says marketing has already scheduled the announcement against it.
# Directory move — `guide/` becomes `docs/guide/`

Date: day 54

The `guide/` directory moves under `docs/`, becoming `docs/guide/`. This is the second
path change for this content, which was originally `handbook/`.

Redirects were shipped in the same change, per the day-36 constraint, and they chain
correctly from the original `handbook/` paths.

**Same pages, same identity, same sign-off.** A page that was signed off under
`handbook/` is still signed off under `docs/guide/`.
# ADR-003 — Authoring format

Status: ACCEPTED
Date: day 9

## Decision

Pages are authored in **MDX**, so that interactive components can be embedded
directly in the prose.

## Context

Three sections need live API consoles. MDX lets us drop a React component inline
rather than iframing a separate app.

## Consequences

The docs build now depends on the React toolchain. Contributors who only write prose
must still run the full build to preview.
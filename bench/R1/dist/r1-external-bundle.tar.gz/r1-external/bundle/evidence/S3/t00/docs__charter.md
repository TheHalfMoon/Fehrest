# Harbor — charter

Harbor migrates 412 pages of internal product documentation off the legacy wiki and
into the versioned documentation site.

Success criteria:

- Every page migrated, with review sign-off per section.
- No external URL breaks. Links published in release notes and support articles must
  keep resolving.
- Search parity or better against the legacy wiki.
# ADR-009 — Authoring format, revised

Status: ACCEPTED
Date: day 45
Supersedes: ADR-003

## Decision

Pages are authored in **plain Markdown with directives**. MDX is dropped.

## Context

ADR-003 chose MDX for three sections needing live consoles. Nine months of contributor
data says the cost landed on everyone else: prose-only contributors could not preview
without the React toolchain, and external contribution dropped to near zero.

The three interactive sections move to a directive that renders the console from a
spec file, which does not require MDX.

## Consequences

**ADR-003 is superseded and is not the current format.** Existing MDX pages are
converted mechanically. The React toolchain leaves the critical build path.
# Constraint — published external URLs must never break

Status: BINDING
Introduced: day 36

Every URL that has been published outside the company — in release notes, support
articles, email campaigns or the status page — **must keep resolving**, permanently.

Any move or rename of a page that has a published URL requires a redirect entry
shipped **in the same change**. A move without its redirect is not deployable.

"We will add the redirects afterwards" is not acceptable and has already caused one
support escalation.